/* API du mode édition. Toutes les routes exigent l'en-tête x-admin-key. */
import { store, checkKey, json } from "../lib/shared.mjs";

const MAX_HISTORY = 15;
const MAX_IMAGE = 5 * 1024 * 1024;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default async (req) => {
  const route = new URL(req.url).pathname.replace(/^\/api\//, "");
  if (req.method !== "POST" && req.method !== "GET") return json({ error: "Méthode non autorisée" }, 405);
  if (!checkKey(req)) { await sleep(800); return json({ error: "Mot de passe incorrect" }, 401); }
  const s = store();

  if (route === "login") return json({ ok: true });

  if (route === "publish" && req.method === "POST") {
    const html = await req.text();
    if (!html.includes("<html") || html.length < 2000 || html.length > 2_000_000)
      return json({ error: "Page invalide, publication annulée" }, 400);
    const prev = await s.get("page");
    if (prev) await s.set("history/" + new Date().toISOString(), prev);
    await s.set("page", html);
    // ne garder que les dernières versions
    const { blobs } = await s.list({ prefix: "history/" });
    const old = blobs.map((b) => b.key).sort().reverse().slice(MAX_HISTORY);
    await Promise.all(old.map((k) => s.delete(k)));
    return json({ ok: true, at: new Date().toISOString() });
  }

  if (route === "upload" && req.method === "POST") {
    const type = req.headers.get("content-type") || "";
    const ext = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" }[type];
    if (!ext) return json({ error: "Format d'image non pris en charge" }, 400);
    const buf = await req.arrayBuffer();
    if (!buf.byteLength || buf.byteLength > MAX_IMAGE) return json({ error: "Image trop lourde (5 Mo max)" }, 413);
    const id = Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8) + "." + ext;
    await s.set("media/" + id, buf, { metadata: { contentType: type } });
    return json({ ok: true, url: "/media/" + id });
  }

  if (route === "history") {
    const { blobs } = await s.list({ prefix: "history/" });
    const versions = blobs.map((b) => b.key.slice(8)).sort().reverse();
    return json({ versions, published: !!(await s.get("page")) });
  }

  if (route === "restore" && req.method === "POST") {
    const { version } = await req.json().catch(() => ({}));
    if (version === "origine") {
      const cur = await s.get("page");
      if (cur) await s.set("history/" + new Date().toISOString(), cur);
      await s.delete("page");
      return json({ ok: true });
    }
    const old = version && (await s.get("history/" + version));
    if (!old) return json({ error: "Version introuvable" }, 404);
    const cur = await s.get("page");
    if (cur) await s.set("history/" + new Date().toISOString(), cur);
    await s.set("page", old);
    return json({ ok: true });
  }

  return json({ error: "Route inconnue" }, 404);
};

export const config = { path: "/api/*" };
