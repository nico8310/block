/* Sert les photos envoyées depuis le mode édition : /media/<id>.jpg */
import { store } from "../lib/shared.mjs";

export default async (req, context) => {
  const key = context.params.key;
  if (!/^[a-z0-9-]+\.(jpg|png|webp)$/i.test(key || "")) return new Response("Introuvable", { status: 404 });
  const res = await store().getWithMetadata("media/" + key, { type: "arrayBuffer" });
  if (!res) return new Response("Introuvable", { status: 404 });
  return new Response(res.data, {
    headers: {
      "content-type": res.metadata?.contentType || "image/jpeg",
      "cache-control": "public, max-age=31536000, immutable",
    },
  });
};

export const config = { path: "/media/:key" };
