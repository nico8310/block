/* Sert la page d'accueil : la dernière version publiée depuis le mode édition,
   ou la page d'origine (base.html) tant que rien n'a été publié. */
import { store } from "../lib/shared.mjs";

export default async (req) => {
  let html = null;
  try { html = await store().get("page"); } catch (e) { console.error("blobs", e); }
  if (!html) {
    const r = await fetch(new URL("/base.html", req.url));
    html = await r.text();
  }
  return new Response(html, {
    headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-cache" },
  });
};

export const config = { path: "/" };
