# Noor-terrassement — site + mode édition

## 1. Mettre le site en ligne (une seule fois)

Le mode édition utilise des fonctions Netlify : le glisser-déposer simple de Netlify ne suffit pas.
Deux options :

**A. Via GitHub (recommandé, mises à jour automatiques)**
1. Crée un dépôt GitHub et envoie-y tout le contenu de ce dossier.
2. Sur app.netlify.com : *Add new site > Import an existing project > GitHub* et choisis le dépôt.
   Laisse les réglages par défaut (tout est déjà dans `netlify.toml`) puis *Deploy*.

**B. Via la ligne de commande**
```
npm install -g netlify-cli
netlify login
netlify deploy --prod
```
(à lancer dans ce dossier)

## 2. Définir le(s) mot(s) de passe

Netlify > ton site > *Site configuration > Environment variables > Add a variable*
- Clé : `ADMIN_PASSWORDS`
- Valeur : `tonMotDePasse` — ou plusieurs séparés par des virgules : `motNico,motSalim`
  (un mot de passe par personne : pour retirer l'accès à quelqu'un, tu supprimes le sien).

Puis *Deploys > Trigger deploy > Deploy site* pour que ce soit pris en compte.

## 3. Recevoir les demandes de devis

Netlify > *Forms* > active la détection des formulaires, puis redéploie.
Ensuite *Forms > Form notifications > Add notification > Email* pour recevoir chaque demande par mail.

## 4. Modifier le site

- Va sur `https://ton-site/admin` (ou lien « Espace gestion » en bas de page).
- Entre le mot de passe.
- Clique sur un texte (pointillés jaunes) et tape. Bouton « Changer la photo » sur chaque image.
- « + Ajouter une réalisation » sous la galerie, « Retirer » pour en enlever une (deux clics).
- **Publier** : rien n'est visible des clients avant ce clic.
- **Versions** : revenir à une publication précédente (les 15 dernières sont gardées), ou au site d'origine.

## Structure
- `public/base.html` — le site d'origine
- `public/editor.js` — le mode édition (chargé seulement sur /admin)
- `public/img/` — photos d'origine
- `netlify/functions/` — page d'accueil, API d'édition, photos envoyées (stockées dans Netlify Blobs)
