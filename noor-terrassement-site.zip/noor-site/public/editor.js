/* Noor-terrassement — mode édition
   Ouvert via /admin (ou /?edit). Les éléments ajoutés ici portent data-ed
   et sont retirés de la page avant publication. */
(() => {
  "use strict";
  const SKEY = "noorAdminKey";
  let key = "";
  try { key = sessionStorage.getItem(SKEY) || ""; } catch (e) {}
  let dirty = false;

  const TEXT_SEL = [
    "header .logo b", "header .logo span", "header nav a",
    "main h1", "main h2", "main h3", "main p:not(.hp)", "main .mono", "main .tag",
    "main .chips span", "main figcaption strong", "main .steps strong", "main .steps span",
    "main .contact span", "main .btn",
    "footer .logo b", "footer .logo span", "footer .small",
  ].join(",");
  const MULTILINE = new Set(["P", "H1", "H2", "H3"]);

  /* ---------- helpers ---------- */
  const el = (tag, attrs = {}, html = "") => {
    const n = document.createElement(tag);
    n.setAttribute("data-ed", "");
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    if (html) n.innerHTML = html;
    return n;
  };

  async function api(path, opts = {}) {
    const r = await fetch("/api/" + path, {
      ...opts,
      headers: { "x-admin-key": key, ...(opts.headers || {}) },
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "Erreur " + r.status);
    return d;
  }

  let toastTimer;
  function toast(msg, bad) {
    let t = document.getElementById("ed-toast");
    if (!t) { t = el("div", { id: "ed-toast", role: "status" }); document.body.appendChild(t); }
    t.textContent = msg;
    t.className = bad ? "bad" : "";
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.hidden = true), 3500);
  }

  function setDirty(v) {
    dirty = v;
    const s = document.getElementById("ed-status");
    if (s) s.textContent = v ? "Modifications non publiées" : "Tout est publié";
    const b = document.getElementById("ed-publish");
    if (b) b.disabled = !v;
  }

  /* Bouton à double clic de confirmation (les boîtes de dialogue du navigateur ne sont pas utilisées) */
  function confirmClick(btn, label, action) {
    const orig = btn.textContent;
    let armed = false, t;
    btn.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      if (!armed) {
        armed = true; btn.textContent = label; btn.classList.add("armed");
        t = setTimeout(() => { armed = false; btn.textContent = orig; btn.classList.remove("armed"); }, 3000);
        return;
      }
      clearTimeout(t); action();
    });
  }

  /* ---------- styles ---------- */
  const css = `
  html.ed-on body{padding-bottom:96px}
  html.ed-on [contenteditable]{outline:1.5px dashed rgba(242,183,5,.85);outline-offset:3px;border-radius:2px;cursor:text}
  html.ed-on [contenteditable]:hover{background:rgba(242,183,5,.10)}
  html.ed-on [contenteditable]:focus{outline:2px solid #F2B705;background:rgba(242,183,5,.14)}
  .ed-rel{position:relative}
  [data-ed]{font-family:"Barlow","Helvetica Neue",Arial,sans-serif;box-sizing:border-box}
  .ed-btn{font:600 14px/1 "Barlow",Arial,sans-serif;border:0;border-radius:3px;padding:10px 14px;cursor:pointer;background:#2B2620;color:#EEE9DF;white-space:nowrap}
  .ed-btn:hover{filter:brightness(1.15)}
  .ed-btn:focus-visible{outline:3px solid #F2B705;outline-offset:2px}
  .ed-btn.primary{background:#F2B705;color:#1D1A15}
  .ed-btn.primary:disabled{opacity:.45;cursor:default;filter:none}
  .ed-btn.armed{background:#B3261E;color:#fff}
  .ed-img{position:absolute;top:10px;left:10px;z-index:3;box-shadow:0 2px 10px rgba(0,0,0,.35)}
  .ed-del{position:absolute;top:10px;right:10px;z-index:3;padding:8px 10px;font-size:13px;box-shadow:0 2px 10px rgba(0,0,0,.35)}
  .ed-busy{opacity:.5;pointer-events:none}
  #ed-add{grid-column:1/-1;justify-self:start;margin-top:4px;padding:14px 18px;font-size:15px;background:transparent;color:var(--ink,#1D1A15);box-shadow:inset 0 0 0 1.5px currentColor}
  #ed-bar{position:fixed;left:0;right:0;bottom:0;z-index:50;background:#1D1A15;color:#EEE9DF;
    padding:12px max(16px,env(safe-area-inset-right,0px)) calc(12px + env(safe-area-inset-bottom,0px)) max(16px,env(safe-area-inset-left,0px));
    display:flex;align-items:center;gap:10px;flex-wrap:wrap;box-shadow:0 -4px 20px rgba(0,0,0,.25)}
  #ed-bar .who{display:flex;flex-direction:column;gap:2px;margin-right:auto;min-width:0}
  #ed-bar .who b{font:800 18px/1 "Big Shoulders Display",Impact,sans-serif;letter-spacing:.04em;text-transform:uppercase;color:#F2B705}
  #ed-bar .who span{font-size:13px;color:#C9BFAE}
  .ed-panel{position:fixed;right:max(16px,env(safe-area-inset-right,0px));bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:51;
    width:min(400px,calc(100vw - 32px));max-height:60vh;overflow:auto;background:#F7F6F2;color:#1D1A15;border-radius:4px;
    padding:20px;box-shadow:0 10px 40px rgba(0,0,0,.35);display:flex;flex-direction:column;gap:12px;font-size:15px;line-height:1.5}
  .ed-panel h4{margin:0;font:800 22px/1 "Big Shoulders Display",Impact,sans-serif;text-transform:uppercase}
  .ed-panel ol{margin:0;padding-left:20px;display:flex;flex-direction:column;gap:6px}
  .ed-panel .ver{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 0;border-top:1px solid #CFCAC0}
  .ed-panel .muted{color:#5E584D;font-size:14px}
  #ed-toast{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(90px + env(safe-area-inset-bottom,0px));z-index:60;
    background:#F2B705;color:#1D1A15;font-weight:600;padding:12px 18px;border-radius:3px;box-shadow:0 6px 24px rgba(0,0,0,.3);max-width:calc(100vw - 32px)}
  #ed-toast.bad{background:#B3261E;color:#fff}
  #ed-login{position:fixed;inset:0;z-index:70;background:rgba(21,19,15,.82);display:grid;place-items:center;padding:16px}
  #ed-login form{background:#F7F6F2;color:#1D1A15;border-radius:4px;padding:28px;width:min(380px,100%);display:flex;flex-direction:column;gap:14px;box-shadow:0 20px 60px rgba(0,0,0,.4)}
  #ed-login h4{margin:0;font:900 34px/0.95 "Big Shoulders Display",Impact,sans-serif;text-transform:uppercase}
  #ed-login p{margin:0;color:#5E584D;font-size:15px}
  #ed-login input{font:16px "Barlow",Arial,sans-serif;padding:12px;border:1.5px solid #CFCAC0;border-radius:3px;background:#fff;color:#1D1A15}
  #ed-login input:focus{outline:none;border-color:#1D1A15}
  #ed-login .err{color:#B3261E;font-weight:600;min-height:1.2em}
  #ed-login a{color:#5E584D;font-size:14px}
  @media (max-width:560px){#ed-bar .ed-btn{padding:9px 11px;font-size:13px}#ed-bar .who span{font-size:12px}html.ed-on body{padding-bottom:140px}#ed-toast{bottom:calc(130px + env(safe-area-inset-bottom,0px))}.ed-panel{bottom:calc(124px + env(safe-area-inset-bottom,0px))}}
  `;
  document.head.appendChild(el("style", {}, css));

  /* ---------- connexion ---------- */
  function showLogin(msg) {
    const box = el("div", { id: "ed-login" }, `
      <form autocomplete="on">
        <h4>Espace gestion</h4>
        <p>Entre ton mot de passe pour modifier les textes et les photos du site.</p>
        <input id="ed-pass" type="password" autocomplete="current-password" placeholder="Mot de passe" required>
        <span class="err" aria-live="polite">${msg || ""}</span>
        <button class="ed-btn primary" type="submit">Entrer</button>
        <a href="/">Retour au site</a>
      </form>`);
    document.body.appendChild(box);
    const input = box.querySelector("#ed-pass");
    input.focus();
    box.querySelector("form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = box.querySelector("button");
      btn.disabled = true; btn.textContent = "Vérification…";
      key = input.value;
      try {
        await api("login", { method: "POST" });
        try { sessionStorage.setItem(SKEY, key); } catch (e) {}
        box.remove();
        enable();
      } catch (err) {
        box.querySelector(".err").textContent = err.message;
        btn.disabled = false; btn.textContent = "Entrer";
        input.select();
      }
    });
  }

  /* ---------- photos ---------- */
  async function compress(file) {
    let src;
    try { src = await createImageBitmap(file, { imageOrientation: "from-image" }); }
    catch (e) {
      src = await new Promise((res, rej) => {
        const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error("Image illisible"));
        i.src = URL.createObjectURL(file);
      });
    }
    const w = src.width, h = src.height, max = 1800;
    const k = Math.min(1, max / Math.max(w, h));
    const c = document.createElement("canvas");
    c.width = Math.round(w * k); c.height = Math.round(h * k);
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(src, 0, 0, c.width, c.height);
    return await new Promise((r) => c.toBlob(r, "image/jpeg", 0.82));
  }

  function pickFile() {
    return new Promise((resolve) => {
      const inp = el("input", { type: "file", accept: "image/*", hidden: "" });
      document.body.appendChild(inp);
      inp.addEventListener("change", () => { resolve(inp.files[0] || null); inp.remove(); });
      inp.click();
    });
  }

  async function uploadPicked() {
    const file = await pickFile();
    if (!file) return null;
    toast("Envoi de la photo…");
    const blob = await compress(file);
    const r = await fetch("/api/upload", {
      method: "POST", headers: { "content-type": "image/jpeg", "x-admin-key": key }, body: blob,
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "Envoi impossible");
    return d.url;
  }

  function decorateImage(img) {
    const parent = img.parentElement;
    if (!parent || parent.querySelector(":scope > .ed-img")) return;
    parent.classList.add("ed-rel");
    const b = el("button", { type: "button", class: "ed-btn primary ed-img" }, "Changer la photo");
    img.after(b);
    b.addEventListener("click", async (e) => {
      e.preventDefault(); e.stopPropagation();
      try {
        parent.classList.add("ed-busy");
        const url = await uploadPicked();
        if (url) { img.src = url; img.removeAttribute("srcset"); setDirty(true); toast("Photo remplacée. Pense à publier."); }
      } catch (err) { toast(err.message, true); }
      finally { parent.classList.remove("ed-busy"); }
    });
  }

  /* ---------- textes ---------- */
  function makeEditable(root) {
    const nodes = [...root.querySelectorAll(TEXT_SEL)].filter((n) => !n.closest("[data-ed]"));
    const set = new Set(nodes);
    nodes.forEach((n) => {
      for (let p = n.parentElement; p; p = p.parentElement) if (set.has(p)) return; // un parent est déjà éditable
      n.setAttribute("contenteditable", "true");
      n.setAttribute("spellcheck", "true");
    });
  }

  /* ---------- galerie ---------- */
  function decorateFigure(fig) {
    if (fig.querySelector(":scope > .ed-del")) return;
    fig.classList.add("ed-rel");
    const del = el("button", { type: "button", class: "ed-btn ed-del" }, "Retirer");
    fig.appendChild(del);
    confirmClick(del, "Confirmer ?", () => { fig.remove(); setDirty(true); toast("Réalisation retirée. Pense à publier."); });
    const img = fig.querySelector("img");
    if (img) decorateImage(img);
  }

  function setupGallery() {
    const gal = document.querySelector(".gallery");
    if (!gal) return;
    gal.querySelectorAll(":scope > figure").forEach(decorateFigure);
    const add = el("button", { type: "button", class: "ed-btn", id: "ed-add" }, "+ Ajouter une réalisation");
    gal.after(add);
    add.addEventListener("click", async () => {
      try {
        add.classList.add("ed-busy");
        const url = await uploadPicked();
        if (!url) return;
        const fig = document.createElement("figure");
        fig.innerHTML = `<img src="" alt="Réalisation Noor-terrassement" loading="lazy"><figcaption><strong>Titre du chantier</strong><span class="mono">Type de travaux</span></figcaption>`;
        fig.querySelector("img").src = url;
        gal.appendChild(fig);
        makeEditable(fig);
        decorateFigure(fig);
        setDirty(true);
        fig.scrollIntoView({ behavior: "smooth", block: "center" });
        const t = fig.querySelector("strong");
        t.focus();
        document.getSelection().selectAllChildren(t);
        toast("Réalisation ajoutée. Écris son titre puis publie.");
      } catch (err) { toast(err.message, true); }
      finally { add.classList.remove("ed-busy"); }
    });
  }

  /* ---------- publication ---------- */
  function serialize() {
    const clone = document.documentElement.cloneNode(true);
    clone.querySelectorAll("[data-ed]").forEach((n) => n.remove());
    clone.querySelectorAll("[contenteditable]").forEach((n) => { n.removeAttribute("contenteditable"); n.removeAttribute("spellcheck"); });
    clone.querySelectorAll(".ed-rel, .ed-busy").forEach((n) => {
      n.classList.remove("ed-rel", "ed-busy");
      if (!n.classList.length) n.removeAttribute("class");
    });
    clone.classList.remove("ed-on");
    if (!clone.classList.length) clone.removeAttribute("class");
    clone.removeAttribute("data-theme");
    return "<!doctype html>\n" + clone.outerHTML;
  }

  async function publish() {
    const b = document.getElementById("ed-publish");
    b.disabled = true; b.textContent = "Publication…";
    try {
      await api("publish", { method: "POST", headers: { "content-type": "text/html" }, body: serialize() });
      setDirty(false);
      toast("Publié. Le site est à jour.");
    } catch (err) {
      toast(err.message, true);
      b.disabled = false;
    } finally { b.textContent = "Publier"; }
  }

  /* ---------- panneaux ---------- */
  function closePanels() { document.querySelectorAll(".ed-panel").forEach((p) => p.remove()); }

  function helpPanel() {
    closePanels();
    const p = el("div", { class: "ed-panel", role: "dialog", "aria-label": "Aide" }, `
      <h4>Comment ça marche</h4>
      <ol>
        <li><b>Textes</b> : clique sur un texte entouré de pointillés jaunes et tape directement.</li>
        <li><b>Photos</b> : bouton « Changer la photo » sur chaque image. Les photos du téléphone sont réduites automatiquement.</li>
        <li><b>Réalisations</b> : « + Ajouter une réalisation » sous la galerie, « Retirer » sur une photo (deux clics).</li>
        <li><b>Publier</b> : rien n'est visible des clients tant que tu n'as pas cliqué sur Publier.</li>
        <li><b>Erreur ?</b> « Versions » permet de revenir à une publication précédente.</li>
      </ol>
      <button class="ed-btn" type="button">Fermer</button>`);
    p.querySelector("button").onclick = closePanels;
    document.body.appendChild(p);
  }

  async function versionsPanel() {
    closePanels();
    const p = el("div", { class: "ed-panel", role: "dialog", "aria-label": "Versions" },
      `<h4>Versions publiées</h4><p class="muted">Chargement…</p>`);
    document.body.appendChild(p);
    try {
      const { versions } = await api("history");
      const fmt = (iso) => new Date(iso).toLocaleString("fr-BE", { dateStyle: "medium", timeStyle: "short" });
      p.innerHTML = `<h4>Versions publiées</h4>
        <p class="muted">Restaurer remet le site public dans l'état choisi. La version actuelle reste dans la liste.</p>
        ${versions.map((v) => `<div class="ver"><span>${fmt(v)}</span><button class="ed-btn" type="button" data-v="${v}">Restaurer</button></div>`).join("") || '<p class="muted">Aucune publication précédente.</p>'}
        <div class="ver"><span>Site d'origine</span><button class="ed-btn" type="button" data-v="origine">Restaurer</button></div>
        <button class="ed-btn" type="button" data-close>Fermer</button>`;
      p.querySelector("[data-close]").onclick = closePanels;
      p.querySelectorAll("[data-v]").forEach((b) =>
        confirmClick(b, "Confirmer ?", async () => {
          try {
            await api("restore", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ version: b.dataset.v }) });
            dirty = false;
            toast("Version restaurée.");
            setTimeout(() => location.reload(), 700);
          } catch (err) { toast(err.message, true); }
        }));
    } catch (err) {
      p.innerHTML = `<h4>Versions publiées</h4><p class="muted">${err.message}</p>`;
    }
  }

  /* ---------- activation ---------- */
  function enable() {
    document.documentElement.classList.add("ed-on");
    makeEditable(document);
    document.querySelectorAll("main img").forEach((img) => { if (!img.closest(".gallery")) decorateImage(img); });
    setupGallery();

    // pas de navigation ni d'envoi de formulaire pendant l'édition
    document.addEventListener("click", (e) => {
      const a = e.target.closest("a");
      if (a && !a.closest("[data-ed]")) e.preventDefault();
    }, true);
    document.addEventListener("submit", (e) => { if (!e.target.closest("[data-ed]")) e.preventDefault(); }, true);

    // collage en texte simple, Entrée = retour à la ligne
    document.addEventListener("paste", (e) => {
      const t = e.target.closest && e.target.closest("[contenteditable]");
      if (!t) return;
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData).getData("text/plain");
      document.execCommand("insertText", false, text);
    });
    document.addEventListener("keydown", (e) => {
      const t = e.target.closest && e.target.closest("[contenteditable]");
      if (!t || e.key !== "Enter") return;
      e.preventDefault();
      if (MULTILINE.has(t.tagName)) document.execCommand("insertLineBreak");
      else t.blur();
    });
    document.addEventListener("input", (e) => {
      if (e.target.closest && e.target.closest("[contenteditable]")) setDirty(true);
    });
    window.addEventListener("beforeunload", (e) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } });

    const bar = el("div", { id: "ed-bar" }, `
      <div class="who"><b>Mode édition</b><span id="ed-status"></span></div>
      <button class="ed-btn" type="button" id="ed-help">Aide</button>
      <button class="ed-btn" type="button" id="ed-versions">Versions</button>
      <button class="ed-btn" type="button" id="ed-quit">Quitter</button>
      <button class="ed-btn primary" type="button" id="ed-publish">Publier</button>`);
    document.body.appendChild(bar);
    bar.querySelector("#ed-help").onclick = helpPanel;
    bar.querySelector("#ed-versions").onclick = versionsPanel;
    bar.querySelector("#ed-publish").onclick = publish;
    const quit = bar.querySelector("#ed-quit");
    quit.addEventListener("click", (e) => {
      if (!dirty) { location.href = "/"; return; }
      if (quit.classList.contains("armed")) { dirty = false; location.href = "/"; return; }
      quit.classList.add("armed"); quit.textContent = "Perdre les modifs ?";
      setTimeout(() => { quit.classList.remove("armed"); quit.textContent = "Quitter"; }, 3000);
    });
    setDirty(false);
    toast("Mode édition actif. Clique sur un texte pour le modifier.");
  }

  /* ---------- démarrage ---------- */
  async function start() {
    if (!key) return showLogin();
    try { await api("login", { method: "POST" }); enable(); }
    catch (e) { try { sessionStorage.removeItem(SKEY); } catch (_) {} key = ""; showLogin(); }
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
